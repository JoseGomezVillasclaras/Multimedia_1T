package main;
import javax.swing.JOptionPane;
import java.util.Random;
public class Principal {
	  public static void main(String[] args) {
	        int numSecreto = gennumSecreto();
	        int intentos = 0;
	        boolean haAdivinado = false;

	        JOptionPane.showMessageDialog(null, "Juego Adivina el Número.\n" +
	                "Tienes que adivinar un número entre 1 y 100.");

	        while (!haAdivinado) {
	            String entrada = JOptionPane.showInputDialog("Ingresa tu respuesta:");
	            int suposicion = Integer.parseInt(entrada);
	            intentos++;

	            if (suposicion == numSecreto) {
	                haAdivinado = true;
	            } else if (suposicion < numSecreto) {
	                JOptionPane.showMessageDialog(null, "El número secreto es mayor. Intento #" + intentos);
	            } else {
	                JOptionPane.showMessageDialog(null, "El número secreto es menor. Intento #" + intentos);
	            }
	        }

	        JOptionPane.showMessageDialog(null, "¡Felicidades! Adivinaste el número en " + intentos + " intentos.");
	    }

	    private static int gennumSecreto() {
	        Random random = new Random();
	        return random.nextInt(100) + 1; 
	    }

}
